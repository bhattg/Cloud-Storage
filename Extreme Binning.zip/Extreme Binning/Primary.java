import java.io.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.util.*;
public class Primary
{
	BigInteger repId=new BigInteger("0");
	BigInteger fileHash=new BigInteger("0");
	ArrayList<bin> Pointer;
	String FileMetaServerAddress;
	String ChunkDataServerAddress;
}
